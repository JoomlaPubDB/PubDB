DROP TABLE IF EXISTS `#__pubdb_Literature`;
